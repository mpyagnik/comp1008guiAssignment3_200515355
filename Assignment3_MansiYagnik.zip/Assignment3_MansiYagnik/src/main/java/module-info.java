module georgiancollege.comp1008.assignment3.assignment3_mansiyagnik {
    requires javafx.controls;
    requires javafx.fxml;


    opens georgiancollege.comp1008.assignment3.assignment3_mansiyagnik to javafx.fxml;
    exports georgiancollege.comp1008.assignment3.assignment3_mansiyagnik;
}